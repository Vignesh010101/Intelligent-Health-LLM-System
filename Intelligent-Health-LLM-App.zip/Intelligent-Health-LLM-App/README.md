# Intelligent Health LLM App
The Streamlit app showcases the practical implementation of the approach outlined in the paper *An Intelligent Health LLM System for Personalized Medication Guidance and Support*.

## Project Structure
This project utilizes Streamlit for the frontend, Firebase for backend services and authentication, and OpenAI endpoints for generating responses.

```
/health-llm-app
│── /.streamlit            # Streamlit configuration (e.g., config.toml)
│── /components            # UI Components (sidebar, footer)
│── /pages                 # Streamlit pages
│── /services              # Backend services (Firebase, AI model)
│── .gitignore             # Files excluded from Git tracking
│── LICENSE                # MIT License for the project
│── README.md              # Project documentation
│── app.py                 # Main entry point
```

> [!NOTE]
> `firebase_config.json` and `secrets.toml` are excluded to safeguard credentials.

## Quick Start Guide
**Prerequisites:** Have Git, Python 3, and pip installed.

**Step 1:** Clone the repository
```
git clone https://github.com/G0v1ndD3v/Intelligent-Health-LLM-App
```

**Step 2:** Install dependencies
```
pip install streamlit firebase-admin
```

**Step 3:** Add `firebase_config.json` to the project folder

**Step 4:** Create `.streamlit/secrets.toml` and add API keys
```
TEXT_API_KEY = "your-openai-api-key"
FIREBASE_WEB_API_KEY = "your-firebase-web-api-key"
```

**Step 5:** Run the application
```
python3 -m streamlit run app.py
```

**Step 6:** Open the displayed URL in your browser

## License
**Copyright © 2025 Dept. of CSA, School of Computing, Amrita Vishwa Vidyapeetham.** \
This project is licensed under the [MIT License](./LICENSE).
